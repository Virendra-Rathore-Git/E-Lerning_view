class EnrollmentsController < ApplicationController
 
  def show
    @all_courses = Course.where(status: "active")
    render json: @all_courses, status: :ok
  end

  def create
    b = User.find(@current_user.id)
    if b.type == "Student"
      @stud_enroll = @current_user.enrollments.new(enroll_params)
      if !@stud_enroll.blank?
      if @stud_enroll.course.status=="active"
        if @stud_enroll.save
          render json: @stud_enroll, status: :ok
        else
          render json: { errors: @stud_enroll.errors.full_messages }, status: :unprocessable_entity
        end
      else
        render json: { errors: "You Can Enroll Only For Acitve Courses" }, status: :unprocessable_entity    
      end
    else
      render json: { errors: "Course With Id #{params[:course_id]},is Not Available" }, status: :unprocessable_entity    
    end
    else
      render json: { errors: "Only Student Can Enroll For Courses" }, status: :unprocessable_entity
    end
  end

  private

  def enroll_params
    params.permit(:course_id)
  end
end
