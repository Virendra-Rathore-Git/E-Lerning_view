class CoursesController < ApplicationController

  def create
    a = User.find(@current_user.id)
    if a.type == "Teacher"
      @course = @current_user.courses.new(course_params)
      if @course.save
        render json: @course, status: :created
      else
        render json: { errors: @course.errors.full_messages }, status: :unprocessable_entity
      end
    else
      render json: { errors: "Only Teacher Can Create Courses" }, status: :unprocessable_entity
    end
  end

  def index
    @teachers_course=Course.where(teacher_id:@current_user.id)

    if @teachers_course
      render json: @teachers_course, status: :ok
    else
      render json: {errors: "Sorry Courses Not Available"}
    end
  end

  def show
    begin
      @teacher_course=Course.where(teacher_id:@current_user.id).find(params[:id])

      render json: @teacher_course, status: :ok
    rescue    
      render json: {errors: "Sorry Course With id #{params[:id]} is Not Available"}
    end
  end

  def show_student_course
    begin
      @student_course=Course.where(student_id:@current_user.id).find(params[:id])
      render json: @student_course, status: :ok
    rescue    
      render json: {errors: "Sorry Course With id #{params[:id]} is Not Available"}
    end
  end

  def show_by_name
    @_course=Course.where("course_name LIKE ?", "%#{params[:course_name]}%")
    if !@_course.blank?
      render json: @_course, status: :ok
    else
      render json: {errors: "Sorry Course With Name #{params[:course_name]} is Not Available"}    
    end
  end


  def show_by_status
    @_course=Course.where(status:params[:status])
    if !@_course.blank?
      render json: @_course, status: :ok
    else
      render json: {errors: "Sorry Course With Status #{params[:status]} is Not Available"}    
    end
  end

  def show_by_cat
   @cat_course=Course.where(category_id:params[:category_id])
   if !@cat_course.blank?
     render json: @cat_course, status: :ok
   else
    render json: {errors: "Sorry Course With Category Id #{params[:category_id]} is Not Available"},status: :unprocessable_entity    
  end
end

def show_enroll_course
  ids=Enrollment.where(student_id:@current_user.id).pluck(:id)

  @enroll_course= Course.where(id:ids).where(status: "active")

  if !@enroll_course.blank?

    render json: @enroll_course, status: :ok
  else
    render json: {errors: "You Are Not Enroll For Any Course"}    

  end
end

def search_in_my_course
  begin
    ids=Enrollment.where(student_id:@current_user.id).pluck(:id)
    @enroll_course= Course.where(id:ids,status:"active")
    @my_course=@enroll_course.find(params[:id])
    render json: @my_course 
  rescue
    render json: {error: "Can't find course of id: #{params[:id]}"}, status: :unprocessable_entity
  end
end

private

def course_params
  params.permit(:course_name, :course_desc, :course_cont, :category_id,:status)
end
end

