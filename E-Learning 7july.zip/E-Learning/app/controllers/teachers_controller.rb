class TeachersController < ApplicationController
  skip_before_action :authenticate_request, only: [:create]
  before_action :set_user, only: [:show, :destroy]

  def create
    @teacher = Teacher.new(user_params)
    if @teacher.save
      render json: @teacher, status: :created
    else
      render json: { errors: @teacher.errors.full_messages }, status: :unprocessable_entity
    end
  end

  private

  def user_params
    params.permit(:name, :email, :password, :mobile, :type)
  end
end
