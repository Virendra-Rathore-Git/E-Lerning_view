class Teacher < User
  has_many :courses
end
