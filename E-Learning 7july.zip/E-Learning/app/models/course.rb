class Course < ApplicationRecord
  belongs_to :teacher
  belongs_to :category

  validates :status, inclusion: { in: ["active", "inactive"] }
  validates :course_name,presence:true,uniqueness:true
  validates :course_desc,presence:true
  validates :course_cont,presence:true
  
end
