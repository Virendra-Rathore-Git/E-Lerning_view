class User < ApplicationRecord
  has_secure_password

  validates :name,presence:true
  validates :mobile,presence:true,uniqueness:true,length: { minimum: 10 }
  validates :email,presence:true,uniqueness:true
  validates :password,presence:true
  validates :type,inclusion: { in: ["Teacher", "Student"] }

  def Student?
    self.type == "Student"
  end

  def Teacher?
    self.type == "Teacher"
  end
end
