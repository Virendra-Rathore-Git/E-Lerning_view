Rails.application.routes.draw do
  

  post "/user/login", to: "authentication#login"

  resources :teachers
  resources :students
  resources :courses ,only:[:create,:index,:show]
  resources :enrollments,only:[:show,:create]

  get "/enrolled/courses", to: "courses#show_enroll_course"
  get "/courses_by_name/:course_name",to: "courses#show_by_name"
  get "/course/status/:status",to: "courses#show_by_status"
  get "/course/cat/:category_id",to: "courses#show_by_cat"
  get "/mycourse/:id", to: "courses#search_in_my_course"
  # get "/student/course/:id",to: "courses#show_student_course"

end



# resources :teachers
  # resources :students

  # post "/teacher/course", to: "courses#create"

  #  get "/courses/teacher",to: "courses#index"

  # get "/course/:id",to: "courses#show"

  # get "/student/course/:id",to: "courses#show_student_course"

  # get "/courses/:course_name",to: "courses#show_by_name"

  # get "/course/status/:status",to: "courses#show_by_status"

  # get "/course/cat/:category_id",to: "courses#show_by_cat"
 
  # get "/enrollments/show"
  # post "/enrollments/create"
  
  # get "/enrolled/courses", to: "courses#show_enroll_course"

  # get "/mycourse/:id", to: "courses#search_in_my_course"


